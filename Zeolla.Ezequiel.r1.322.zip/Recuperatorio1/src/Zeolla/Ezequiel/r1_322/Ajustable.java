package Zeolla.Ezequiel.r1_322;

public interface Ajustable {
    public void ajustar();
}
