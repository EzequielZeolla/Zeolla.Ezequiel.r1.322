package Zeolla.Ezequiel.r1_322;

public class Ala extends PiezaParticular implements Ajustable{
    private int cargaAerodinamica;
    private final int MIN_CARGA = 1;
    private final int MAX_CARGA = 10;

    public Ala(int cargaAerodinamica, String nombre, String ubicacion, CondicionClimatica condicion, boolean estado) {
        super(nombre, ubicacion, condicion, estado);
                
        validarCarga(cargaAerodinamica);
        
        this.cargaAerodinamica = cargaAerodinamica;
    }
    
    
    private void validarCarga(int carga){
        if(carga < MIN_CARGA || carga > MAX_CARGA){
            throw new IllegalArgumentException("Carga aerodinamica fuera de rango");
        }
    }
    
    @Override
    public void ajustar(){
        System.out.println("d" + getNombre());
    }

    @Override
    public String toString() {
        return "Ala{" + "cargaAerodinamica=" + cargaAerodinamica + '}';
    }
    
    
    
    
    
}
