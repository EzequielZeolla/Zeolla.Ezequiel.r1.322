package Zeolla.Ezequiel.r1_322;

public class Motor extends PiezaParticular implements Ajustable{
    private int potenciaMaxima;

    public Motor(int potenciaMaxima, String nombre, String ubicacion, CondicionClimatica condicion, boolean estado) {
        super(nombre, ubicacion, condicion, estado);
        this.potenciaMaxima = potenciaMaxima;
    }

    public int getPotenciaMaxima() {
        return potenciaMaxima;
    }

    @Override
    public void ajustar(){
        System.out.println("l" + getNombre());
    }

    @Override
    public String toString() {
        return "Motor{" + "potenciaMaxima=" + potenciaMaxima + '}';
    }
    
    
    
}
