package Zeolla.Ezequiel.r1_322;

public class PiezaDuplicadaException extends RuntimeException{
    private static final String MESSAGE = "Pieza repetida";
    
    public PiezaDuplicadaException(){
        this(MESSAGE);
    }
    
    public PiezaDuplicadaException(String mensaje){
        super(mensaje);
    }
}
