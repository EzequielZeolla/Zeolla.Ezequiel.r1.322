package Zeolla.Ezequiel.r1_322;

import java.util.ArrayList;
import java.util.List;

public class Box {
    private ArrayList<PiezaParticular> piezas = new ArrayList<>();
    
    public void agregarPieza(PiezaParticular c){
        validarPieza(c);
        if(piezas.contains(c)){
            throw new PiezaDuplicadaException("Pieza repetidas: (" + infoPieza(c) + ")");
        }
        piezas.add(c);
    }
    
    public void mostrarPieza(){
        validarLista();
        
        for(PiezaParticular p : piezas){
            System.out.println(p);
        }
    }
    
    public boolean ajustar(PiezaParticular p, boolean estado) {
        validarPieza(p); // Verifica que no sea null
        
        while (estado) {
            System.out.println("La pieza " + p.getNombre() + " fue ajustada correctamente.");
            return true;   
        } {
            System.out.println("El estado no permite ajustar la pieza.");
            return false;
        }
    }
    
    public void ajustarPieza(PiezaParticular p, boolean estado){
        ajustar(p, estado);
    }

    
    private String infoPieza(PiezaParticular p){
        return p.getNombre() + " , " + p.getUbicacion();
    }
    
    public void validarLista(){
        if(piezas.isEmpty()){
            throw new IllegalArgumentException("Lista vacia");
        }
    }
    
    
    
    public List<PiezaParticular> buscarPiezasPorCondicion(CondicionClimatica condicion){
        validarCondicion(condicion);
        List<PiezaParticular> r = new ArrayList<>();
        
        
        for(PiezaParticular p : piezas){
            if(p.getCondicion() == condicion){
                r.add(p);
            }
            return r;
        }
        return null;
    }    
    
        
    private void validarCondicion(CondicionClimatica c){
        if(c == null){
            throw new IllegalArgumentException("Condicion nula");
        }
    }
            
    private void validarPieza(PiezaParticular p){
        if(p == null){
            throw new IllegalArgumentException("Pieza nuela");
        }
    }
}
