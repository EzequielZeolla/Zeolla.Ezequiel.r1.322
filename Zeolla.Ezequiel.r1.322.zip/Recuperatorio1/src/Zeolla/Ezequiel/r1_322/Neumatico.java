package Zeolla.Ezequiel.r1_322;

public class Neumatico extends PiezaParticular{
    private final Compuesto compuesto;

    public Neumatico(Compuesto compuesto, String nombre, String ubicacion, CondicionClimatica condicion, boolean estado) {
        super(nombre, ubicacion, condicion, estado);
        this.compuesto = compuesto;
    }

    public Compuesto getCompuesto() {
        return compuesto;
    }
    
    public String toString() {
        return "Neumatico{" + "compuesto=" + compuesto + "}";
    }        
}
