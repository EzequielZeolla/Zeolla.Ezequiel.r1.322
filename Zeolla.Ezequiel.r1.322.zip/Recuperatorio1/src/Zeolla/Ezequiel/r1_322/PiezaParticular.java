package Zeolla.Ezequiel.r1_322;

public class PiezaParticular {
    private String nombre;
    private String ubicacion;
    private CondicionClimatica condicion;
    private boolean estado;

    public PiezaParticular(String nombre, String ubicacion, CondicionClimatica condicion, boolean estado) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.condicion = condicion;
        this.estado = estado;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public CondicionClimatica getCondicion() {
        return condicion;
    }

    public boolean getEstado() {
        return estado;
    }
    
        
    @Override
    public boolean equals(Object o){
        if(o ==this){
            return true;
        }
        if(o == null || !(o instanceof PiezaParticular p)){
            return false;
        }
        return nombre.equals(p.nombre) && ubicacion.equals(p.ubicacion);  
    }
    
    public String mostar(){
        StringBuilder sb = new StringBuilder();
        sb.append("nombre: ").append(nombre).append("\n");
        sb.append("Ubicacion: ").append(ubicacion).append("\n");
        sb.append("Condicion: ").append(condicion).append("\n");
        
        return sb.toString();
    }
    
    @Override
    public String toString(){
        return this.mostar();
    }
}
    
