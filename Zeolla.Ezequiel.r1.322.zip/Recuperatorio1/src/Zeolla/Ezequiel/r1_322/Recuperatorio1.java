package Zeolla.Ezequiel.r1_322;

public class Recuperatorio1 {

    public static void main(String[] args) {
        Box gestor = new Box();

        // Crear algunas piezas
        PiezaParticular p1 = new PiezaParticular("Tornillo", "Deposito", CondicionClimatica.LLUVIA, true);
        PiezaParticular p2 = new PiezaParticular("Tuerca", "Almacen", CondicionClimatica.MIXTO, true);
        PiezaParticular p3 = new PiezaParticular("Engranaje", "Fbrica", CondicionClimatica.SECO, false);
        PiezaParticular p4 = new PiezaParticular("Enranaje", "Fbrica", CondicionClimatica.SECO, false);
        PiezaParticular p5 = new PiezaParticular("Engranaj", "Fbr", CondicionClimatica.SECO, true);
        PiezaParticular p6 = new PiezaParticular("Engrana", "Fbra", CondicionClimatica.SECO, true);
        PiezaParticular p7 = new PiezaParticular("Engran", "Fb", CondicionClimatica.SECO, false);

        // Agregar piezas
        gestor.agregarPieza(p1);
        
        
        // Mostrar todas las piezas
        gestor.mostrarPieza();
        
        // Intentar agregar una pieza repetida
        
        System.out.println(gestor.buscarPiezasPorCondicion(CondicionClimatica.SECO));

        // Ajustar las piezas
        System.out.println("\n--- Ajustando piezas ---");
        gestor.ajustarPieza(p1, p1.getEstado());
        
        
    
    }
    
}
