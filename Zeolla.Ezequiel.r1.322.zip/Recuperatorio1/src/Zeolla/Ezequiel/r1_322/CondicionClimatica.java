package Zeolla.Ezequiel.r1_322;

public enum CondicionClimatica {
    SECO,
    LLUVIA,
    MIXTO
}
