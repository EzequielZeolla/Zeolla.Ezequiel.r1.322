package Zeolla.Ezequiel.r1_322;

public abstract class Pieza {
    private String nombre;
    private String ubicacion;
    private CondicionClimatica condicion;
    private boolean estado;
}
